import 'package:flutter/material.dart';
import 'package:googleNewsFede/models/article.dart';
import 'package:googleNewsFede/services/api.dart';

final List<Article> _articles = [];
class ArticleHolder extends ChangeNotifier {

  ArticleHolder() {
    Api api = new Api();
    api.getInitialArticle().then((value) => articles = value);
    notifyListeners();
  }
  
  set articles(List<Article> news) {
    _articles.clear();
    _articles.addAll(news);

    notifyListeners();
  }

  List<Article> get articles => _articles;

}
