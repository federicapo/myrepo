import 'package:flutter/material.dart';
import 'package:googleNewsFede/models/article.dart';

class NewsItem extends StatelessWidget {
  final Article article;
  NewsItem(this.article, {key: Key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(children: <Widget>[
        Image.network(article.urlToImage),
        Text(article.description)
      ]),
    );
  }
  // @override
  // _NewsItem createState() => _NewsItemState();
}
