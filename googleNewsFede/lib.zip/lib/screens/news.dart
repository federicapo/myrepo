import 'package:flutter/material.dart';
import 'package:googleNewsFede/models/articlesHolder.dart';
import 'package:provider/provider.dart';

class News extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("NEWS APP"),
      ),
      body: new Container(
        child: new Center(
          child: Container(
            child: Consumer<ArticleHolder>(
              builder: (context, news, child) {
                return ListView.builder(
                    itemCount: news.articles.length,
                    itemBuilder: (context, position) =>
                        Text(news.articles[position].title));
              },
            ),
          ),
        ),
      ),
    );
  }

  // TabController getTabController() {
  //   return TabController(length: 2);
  // }

  // Tab getTab(String category) {
  //   return Tab(
  //     text: category,
  //   );
  // }

 
}
